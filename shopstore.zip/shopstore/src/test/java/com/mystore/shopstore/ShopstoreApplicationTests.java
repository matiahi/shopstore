package com.mystore.shopstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
