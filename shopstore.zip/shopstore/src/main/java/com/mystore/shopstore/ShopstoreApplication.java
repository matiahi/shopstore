package com.mystore.shopstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopstoreApplication.class, args);
	}

}
